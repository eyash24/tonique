# Trial functions

def hello():
    print("Hello from tonique app.")