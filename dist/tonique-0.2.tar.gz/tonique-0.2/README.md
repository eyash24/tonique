# Tonique

Building packages
'''
python setup.py sdist bdist wheel
'''